-- ================================================================
--  CREATOR CLUB — Schema Patch for existing installs
--  Run this in Supabase SQL Editor IF you already ran the
--  original supabase-schema.sql. Skip if starting fresh.
-- ================================================================

-- Remove is_creator column — any user can now run a club
ALTER TABLE profiles DROP COLUMN IF EXISTS is_creator;

-- Fix the profile trigger to not reference is_creator
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO profiles (id, makerworld_username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'makerworld_username', split_part(NEW.email,'@',1))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Done
