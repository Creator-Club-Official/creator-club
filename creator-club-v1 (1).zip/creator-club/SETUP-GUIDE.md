# Creator Club — Setup Guide (GitHub Web Only)

No terminal, no Git, no code editor needed. Everything is done in your browser.
Estimated time: **30–45 minutes**.

---

## What You'll Need

- A GitHub account (free) — [github.com](https://github.com)
- A Supabase account (free) — [supabase.com](https://supabase.com)
- The `creator-club-v1.zip` file you downloaded

---

## Part 1: Set Up Supabase

### 1.1 Create a Project

1. Go to [supabase.com](https://supabase.com) and sign in or create a free account.
2. Click **New Project**.
3. Fill in:
   - **Name:** `creator-club`
   - **Database Password:** choose a strong password and save it somewhere safe
   - **Region:** pick the one closest to you
4. Click **Create new project** and wait about 2 minutes for it to spin up.

### 1.2 Run the Database Schema

1. In your Supabase project, click **SQL Editor** in the left sidebar.
2. Click **New Query**.
3. Open the `supabase-schema.sql` file from your download in any text editor (Notepad, TextEdit, etc.).
4. Select all the text (Ctrl+A / Cmd+A) and copy it.
5. Paste it into the Supabase SQL editor.
6. Click **Run** (green button, top right).
7. You should see: `Success. No rows returned.`

This creates all your tables, security rules, and indexes in one shot.

### 1.3 Turn Off Email Confirmation

1. In Supabase, go to **Authentication** in the left sidebar.
2. Click **Providers**, make sure **Email** is enabled.
3. Click **Email** to expand it.
4. Toggle **Confirm email** to **OFF**.
5. Click **Save**.

> This lets members sign up instantly without needing to verify an email — much better for beta.

### 1.4 Copy Your API Keys

1. In Supabase, click the **gear icon (⚙)** at the bottom of the left sidebar → **Project Settings**.
2. Click **API** in the settings menu.
3. You need two things — copy them somewhere (Notepad works):
   - **Project URL** — looks like `https://abcdefghijk.supabase.co`
   - **anon public** key — a long string starting with `eyJ...`

---

## Part 2: Create the GitHub Repository

### 2.1 Make a New Repo

1. Go to [github.com/new](https://github.com/new).
2. Fill in:
   - **Repository name:** `creator-club`
   - **Visibility:** ✅ **Public** (required for free GitHub Pages)
   - Leave everything else as default
3. Click **Create repository**.

You'll land on an empty repository page.

### 2.2 Upload All the Files

You need to upload the files from the ZIP. First, unzip `creator-club-v1.zip` on your computer so you can see the individual files inside the `creator-club` folder.

**Upload the files in the root folder first:**

1. On your empty GitHub repo page, click **uploading an existing file** (the link in the middle of the page).
2. Drag and drop these files from the unzipped `creator-club` folder into the upload area:
   - `index.html`
   - `login.html`
   - `dashboard.html`
   - `club.html`
   - `inbox.html`
   - `creator-dashboard.html`
   - `creator-posts.html`
   - `creator-members.html`
   - `creator-codes.html`
   - `creator-dm.html`
   - `supabase-schema.sql`
   - `.nojekyll`
3. At the bottom, leave the commit message as-is and click **Commit changes**.

**Upload the `css` folder:**

1. Click **Add file → Upload files** (top right of your repo).
2. Drag and drop `css/style.css` from your unzipped folder.
3. In the commit box, type the path manually — GitHub needs to know the folder. Before committing, look at the filename field at the top of the page — it will say `style.css`. Click into that field and change it to `css/style.css` (add `css/` before the filename).
4. Click **Commit changes**.

**Upload the `js` folder:**

1. Click **Add file → Upload files** again.
2. Drag and drop `js/supabase.js`.
3. Same as above — change the filename field to `js/supabase.js`.
4. Click **Commit changes**.

**Upload the `assets` folder:**

1. Click **Add file → Upload files** again.
2. Drag and drop `assets/logo.png`.
3. Change the filename to `assets/logo.png`.
4. Click **Commit changes**.

> **Tip:** GitHub's web uploader may let you drag entire folders in some browsers (Chrome works best). If it does, just drag the whole `css`, `js`, and `assets` folders in one go.

---

## Part 3: Edit Your API Keys in GitHub

This is the most important step — without your Supabase keys the app won't connect to the database.

1. In your GitHub repo, click into the `js` folder, then click `supabase.js`.
2. Click the **pencil icon ✏️** (Edit this file) in the top right of the file view.
3. Find these two lines near the very top of the file:

```javascript
const SUPABASE_URL  = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'YOUR_ANON_KEY_HERE';
```

4. Replace them with your actual values you copied in step 1.4:

```javascript
const SUPABASE_URL  = 'https://abcdefghijk.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1Ni...';
```

5. Scroll to the bottom and click **Commit changes** → **Commit changes** again in the popup.

---

## Part 4: Enable GitHub Pages

1. In your GitHub repo, click **Settings** (tab at the top).
2. In the left sidebar, click **Pages**.
3. Under **Source**, select **Deploy from a branch**.
4. Set **Branch** to `main` and folder to `/ (root)`.
5. Click **Save**.
6. Wait about 60 seconds, then refresh. You'll see:
   > Your site is live at `https://YOUR_USERNAME.github.io/creator-club/`

That's your public URL. Write it down.

---

## Part 5: Update Supabase With Your Live URL

Supabase needs to know your site's URL to allow logins from it.

1. Go back to Supabase → **Authentication** → **URL Configuration**.
2. Under **Site URL**, enter:
   ```
   https://YOUR_USERNAME.github.io/creator-club
   ```
3. Under **Redirect URLs**, click **Add URL** and enter:
   ```
   https://YOUR_USERNAME.github.io/creator-club/**
   ```
4. Click **Save**.

---

## Part 6: Test Everything

Open your live site: `https://YOUR_USERNAME.github.io/creator-club/`

### Create a Creator Account

1. Click **Create an Account**.
2. Enter your MakerWorld username, a password, and select **Creator — Run my own club**.
3. Click **Create Account** — you'll land on the Creator Dashboard.
4. Enter a club name and description, then click **Create Club**.

### Generate Invite Codes

1. Click **Invite Codes** in the left sidebar.
2. Set Member Type to **Follower** and click **Generate Code** — copy the code.
3. Do the same for **Booster** — copy that code too.

### Test as a Member

1. Open a **Private / Incognito window** and go to your login URL.
2. Click **Create an Account**, enter a different MakerWorld username, and select **Member**.
3. Click **Create Account** — you'll land on the Member Dashboard.
4. Click **+ Join a Club** and enter one of the codes.
5. The club should appear in your list — click it to see the feed!

### Test a Post

1. Back in your Creator account (regular browser window), go to **Posts → New Post**.
2. Create any post — announcement, model, pre-release, or poll.
3. In your Member window, refresh the club page — the post appears!

---

## Part 7: Share With Your MakerWorld Community

Copy this into your MakerWorld bio, swapping in your real URL and codes:

```
🔑 Join my Creator Club — exclusive models & pre-releases!
👉 https://YOUR_USERNAME.github.io/creator-club

Follower code: XXXX-XXXX
Booster code:  YYYY-YYYY
```

---

## Making Updates Later

To edit any file after setup (e.g. to add content or change settings):

1. Go to your GitHub repo.
2. Click the file you want to edit.
3. Click the **pencil icon ✏️**.
4. Make your changes.
5. Click **Commit changes**.

Your live site updates within about 60 seconds.

To replace a file entirely (like uploading a new version):

1. Navigate to the file in GitHub.
2. Click the **three dots ···** menu → **Delete file** → Commit.
3. Then upload the new version via **Add file → Upload files**.

---

## File Reference

| File | Purpose |
|------|---------|
| `login.html` | Sign in & create account |
| `dashboard.html` | Member's club list & join-with-code |
| `club.html` | Club content feed (posts, polls, models) |
| `inbox.html` | Member DM inbox |
| `creator-dashboard.html` | Creator stats & overview |
| `creator-posts.html` | Create & manage posts |
| `creator-members.html` | View all club members |
| `creator-codes.html` | Generate & manage invite codes |
| `creator-dm.html` | Send DMs or broadcast messages |
| `js/supabase.js` | All backend logic — **your API keys go here** |
| `css/style.css` | All styling |
| `supabase-schema.sql` | Database schema — run once in Supabase |
| `.nojekyll` | Tells GitHub Pages to serve all files |

---

## Membership Status Reference

| Status | Meaning | How they get it |
|--------|---------|----------------|
| 1 | Follower | Redeems a Follower code |
| 2 | Booster | Redeems a Booster code |
| 3 | Follower & Booster | Redeems both codes (auto-upgraded) |

---

## Troubleshooting

**Blank white page when opening the site**
→ Check that `index.html` was uploaded correctly. Also make sure GitHub Pages is enabled (Part 4).

**"Invalid or expired code" when a member tries to join**
→ Go to Creator → Invite Codes and confirm the code shows as active. Check for typos — codes are case-insensitive but dashes matter (e.g. `ABCD-1234`).

**Blank page with no content, errors in browser**
→ Press F12 → Console tab. If you see a Supabase error, your API keys in `js/supabase.js` are probably wrong or have extra spaces. Edit the file in GitHub and double-check them.

**"new row violates row-level security" error**
→ The SQL schema wasn't fully applied. Go to Supabase → SQL Editor → New Query, paste the full contents of `supabase-schema.sql`, and run it again.

**Site not updating after editing a file**
→ GitHub Pages takes up to 2 minutes. Do a hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac).

**Members can see posts they shouldn't**
→ Check the member's status in Creator → Members. Also check the post's "Visible To" setting in Creator → Posts.

---

## What's Coming in v2

- Pre-release model auto-archive once creator marks it posted on MakerWorld
- Rich text / image support in posts
- Comment threads on posts
- Public creator profile pages
- Multiple clubs per creator
- Email notifications for new posts
