-- ================================================================
--  CREATOR CLUB — Supabase Database Schema
--  Run this entire file in:
--  Supabase Dashboard → SQL Editor → New Query → Paste & Run
-- ================================================================

-- ── PROFILES ──────────────────────────────────────────────────
-- One row per auth user. Mirrors auth.users.
CREATE TABLE IF NOT EXISTS profiles (
  id                  UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  makerworld_username TEXT NOT NULL UNIQUE,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-create a profile whenever a new auth user is created
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO profiles (id, makerworld_username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'makerworld_username', split_part(NEW.email,'@',1))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ── CLUBS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clubs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id  UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(creator_id)  -- one club per creator for beta
);

-- ── MEMBERSHIP CODES ──────────────────────────────────────────
-- membership_status: 1=follower, 2=booster, 3=both
CREATE TABLE IF NOT EXISTS membership_codes (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  club_id           UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  code              TEXT NOT NULL UNIQUE,
  membership_status INT  NOT NULL CHECK (membership_status IN (1,2,3)),
  is_one_time       BOOLEAN NOT NULL DEFAULT FALSE,
  max_uses          INT,          -- NULL = unlimited
  uses              INT NOT NULL DEFAULT 0,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── MEMBERSHIPS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS memberships (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  club_id           UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  makerworld_username TEXT NOT NULL,
  membership_status INT NOT NULL CHECK (membership_status IN (1,2,3)),
  joined_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, club_id)
);

-- ── POSTS ─────────────────────────────────────────────────────
-- type: 'announcement' | 'model' | 'prerelease' | 'poll'
CREATE TABLE IF NOT EXISTS posts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  club_id       UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  type          TEXT NOT NULL CHECK (type IN ('announcement','model','prerelease','poll')),
  title         TEXT NOT NULL,
  body          TEXT,
  target_status INT NOT NULL CHECK (target_status IN (1,2,3)),
  model_url     TEXT,
  is_published  BOOLEAN NOT NULL DEFAULT TRUE,
  scheduled_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── POLL OPTIONS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS poll_options (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id     UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL,
  votes       INT NOT NULL DEFAULT 0
);

-- ── POLL VOTES ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS poll_votes (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  option_id  UUID NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(option_id, user_id)
);

-- RPC to safely increment poll votes
CREATE OR REPLACE FUNCTION increment_poll_votes(option_id_param UUID)
RETURNS VOID LANGUAGE SQL SECURITY DEFINER AS $$
  UPDATE poll_options SET votes = votes + 1 WHERE id = option_id_param;
$$;

-- ── MESSAGES ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  club_id      UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  sender_id    UUID NOT NULL REFERENCES profiles(id),
  recipient_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content      TEXT NOT NULL,
  is_broadcast BOOLEAN NOT NULL DEFAULT FALSE,
  is_read      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
--  ROW LEVEL SECURITY (RLS)
-- ================================================================

ALTER TABLE profiles         ENABLE ROW LEVEL SECURITY;
ALTER TABLE clubs            ENABLE ROW LEVEL SECURITY;
ALTER TABLE membership_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships      ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts            ENABLE ROW LEVEL SECURITY;
ALTER TABLE poll_options     ENABLE ROW LEVEL SECURITY;
ALTER TABLE poll_votes       ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages         ENABLE ROW LEVEL SECURITY;

-- PROFILES
CREATE POLICY "Profiles: public read"      ON profiles FOR SELECT USING (true);
CREATE POLICY "Profiles: own insert"       ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Profiles: own update"       ON profiles FOR UPDATE USING (auth.uid() = id);

-- CLUBS
CREATE POLICY "Clubs: public read"         ON clubs FOR SELECT USING (true);
CREATE POLICY "Clubs: creator insert"      ON clubs FOR INSERT
  WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Clubs: creator update"      ON clubs FOR UPDATE
  USING (auth.uid() = creator_id);

-- MEMBERSHIP CODES: creators manage their own; anyone can read active
CREATE POLICY "Codes: active read"         ON membership_codes FOR SELECT
  USING (is_active = true);
CREATE POLICY "Codes: creator full"        ON membership_codes FOR ALL
  USING (club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid()));

-- MEMBERSHIPS
CREATE POLICY "Memberships: own read"      ON memberships FOR SELECT
  USING (user_id = auth.uid()
    OR club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid()));
CREATE POLICY "Memberships: self insert"   ON memberships FOR INSERT
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Memberships: self update"   ON memberships FOR UPDATE
  USING (auth.uid() = user_id);

-- POSTS: members of matching status can read published posts
CREATE POLICY "Posts: member read"         ON posts FOR SELECT
  USING (
    is_published = true
    AND club_id IN (
      SELECT club_id FROM memberships
      WHERE user_id = auth.uid()
        AND (membership_status = target_status
          OR membership_status = 3
          OR target_status = 3)
    )
  );
CREATE POLICY "Posts: creator full"        ON posts FOR ALL
  USING (club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid()));

-- POLL OPTIONS
CREATE POLICY "Poll options: member read"  ON poll_options FOR SELECT USING (
  post_id IN (SELECT id FROM posts WHERE is_published = true)
);
CREATE POLICY "Poll options: creator write" ON poll_options FOR INSERT
  WITH CHECK (
    post_id IN (SELECT id FROM posts
      WHERE club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid()))
  );

-- POLL VOTES
CREATE POLICY "Poll votes: own read"       ON poll_votes FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Poll votes: own insert"     ON poll_votes FOR INSERT WITH CHECK (auth.uid() = user_id);

-- MESSAGES
CREATE POLICY "Messages: own inbox"        ON messages FOR SELECT
  USING (recipient_id = auth.uid()
    OR sender_id = auth.uid()
    OR club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid()));
CREATE POLICY "Messages: creator send"     ON messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id
    AND club_id IN (SELECT id FROM clubs WHERE creator_id = auth.uid())
  );
CREATE POLICY "Messages: mark read"        ON messages FOR UPDATE
  USING (recipient_id = auth.uid());

-- ================================================================
--  INDEXES (performance)
-- ================================================================
CREATE INDEX IF NOT EXISTS idx_memberships_user      ON memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_club      ON memberships(club_id);
CREATE INDEX IF NOT EXISTS idx_posts_club            ON posts(club_id);
CREATE INDEX IF NOT EXISTS idx_posts_published       ON posts(is_published, club_id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient    ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_codes_code            ON membership_codes(code);
CREATE INDEX IF NOT EXISTS idx_poll_options_post     ON poll_options(post_id);
